from decouple import config

# Load environment variables
class Config:
    SECRET_KEY = config('SECRET_KEY')

class DevelopmentConfig(Config):
    DEBUG = True
    

config = {
    'development': DevelopmentConfig,
    'default': DevelopmentConfig
}
